
import React, { useState, useCallback, useRef, ChangeEvent } from 'react';
import { generateStl } from './services/stlGenerator';
import type { StlOptions } from './types';

// SVG Icons defined outside component to prevent re-creation
const UploadIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
    </svg>
);

const DownloadIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
);

const LoadingSpinner = () => (
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-accent"></div>
);

const App: React.FC = () => {
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [stlBlobUrl, setStlBlobUrl] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [options, setOptions] = useState<StlOptions>({
        baseHeight: 1,
        maxHeight: 10,
        invert: false,
        resolution: 512,
    });
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (files: FileList | null) => {
        if (files && files[0]) {
            const file = files[0];
            if (!file.type.startsWith('image/')) {
                setError('Please upload a valid image file (PNG, JPG, etc.).');
                return;
            }
            setError(null);
            setImageFile(file);
            setImageUrl(URL.createObjectURL(file));
            setStlBlobUrl(null);
        }
    };

    const handleDragOver = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
        e.preventDefault();
        e.stopPropagation();
    }, []);

    const handleDrop = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
        e.preventDefault();
        e.stopPropagation();
        handleFileChange(e.dataTransfer.files);
    }, []);

    const handleOptionChange = (e: ChangeEvent<HTMLInputElement>) => {
        const { name, value, type, checked } = e.target;
        setOptions(prev => ({
            ...prev,
            [name]: type === 'checkbox' ? checked : parseFloat(value),
        }));
    };

    const handleGenerateStl = async () => {
        if (!imageFile) {
            setError('Please upload an image first.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setStlBlobUrl(null);

        try {
            const image = new Image();
            image.src = imageUrl!;
            image.onload = async () => {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    throw new Error('Could not get canvas context.');
                }

                // Scale image to desired resolution
                const aspectRatio = image.width / image.height;
                if (aspectRatio > 1) {
                    canvas.width = options.resolution;
                    canvas.height = options.resolution / aspectRatio;
                } else {
                    canvas.height = options.resolution;
                    canvas.width = options.resolution * aspectRatio;
                }
                
                ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
                const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

                const stlBlob = await generateStl(imageData, options);
                const url = URL.createObjectURL(stlBlob);
                setStlBlobUrl(url);
                setIsLoading(false);
            };
            image.onerror = () => {
                setError('Failed to load the image.');
                setIsLoading(false);
            }
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
            setIsLoading(false);
        }
    };

    const clearImage = () => {
        setImageFile(null);
        setImageUrl(null);
        setStlBlobUrl(null);
        setError(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    return (
        <div className="min-h-screen bg-gray-900 text-light p-4 sm:p-6 lg:p-8">
            <div className="max-w-4xl mx-auto">
                <header className="text-center mb-8">
                    <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-blue-600">
                        Image to STL Converter
                    </h1>
                    <p className="mt-2 text-gray-400">Turn your 2D images into 3D printable models.</p>
                </header>

                <main className="space-y-8">
                    <div className="bg-secondary p-6 rounded-lg shadow-xl">
                        <h2 className="text-2xl font-semibold mb-4 border-b border-gray-700 pb-2">1. Upload Your Image</h2>
                        {!imageUrl ? (
                            <>
                                <label
                                    onDragOver={handleDragOver}
                                    onDrop={handleDrop}
                                    className="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-600 border-dashed rounded-lg cursor-pointer bg-gray-800 hover:bg-gray-700 transition-colors"
                                >
                                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                        <UploadIcon />
                                        <p className="mb-2 text-sm text-gray-400"><span className="font-semibold">Click to upload</span> or drag and drop</p>
                                        <p className="text-xs text-gray-500">PNG, JPG, GIF, etc.</p>
                                    </div>
                                    <input
                                        ref={fileInputRef}
                                        type="file"
                                        accept="image/*"
                                        className="hidden"
                                        onChange={(e) => handleFileChange(e.target.files)}
                                    />
                                </label>
                                {error && <p className="mt-2 text-sm text-red-500">{error}</p>}
                            </>
                        ) : (
                            <div className="text-center">
                                <img src={imageUrl} alt="Uploaded preview" className="max-h-80 mx-auto rounded-lg shadow-md" />
                                <button
                                    onClick={clearImage}
                                    className="mt-4 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
                                >
                                    Clear Image
                                </button>
                            </div>
                        )}
                    </div>

                    {imageUrl && (
                        <>
                            <div className="bg-secondary p-6 rounded-lg shadow-xl">
                                <h2 className="text-2xl font-semibold mb-4 border-b border-gray-700 pb-2">2. Adjust Settings</h2>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label htmlFor="baseHeight" className="block text-sm font-medium text-gray-300">Base Thickness (mm): {options.baseHeight}</label>
                                        <input type="range" id="baseHeight" name="baseHeight" min="0.1" max="10" step="0.1" value={options.baseHeight} onChange={handleOptionChange} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer" />
                                    </div>
                                    <div>
                                        <label htmlFor="maxHeight" className="block text-sm font-medium text-gray-300">Detail Height (mm): {options.maxHeight}</label>
                                        <input type="range" id="maxHeight" name="maxHeight" min="1" max="50" step="1" value={options.maxHeight} onChange={handleOptionChange} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer" />
                                    </div>
                                    <div>
                                        <label htmlFor="resolution" className="block text-sm font-medium text-gray-300">Resolution (Longest Side): {options.resolution}px</label>
                                        <input type="range" id="resolution" name="resolution" min="128" max="1024" step="32" value={options.resolution} onChange={handleOptionChange} className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer" />
                                    </div>
                                    <div className="flex items-center justify-center">
                                        <label className="flex items-center cursor-pointer">
                                            <input type="checkbox" name="invert" checked={options.invert} onChange={handleOptionChange} className="sr-only peer" />
                                            <div className="relative w-11 h-6 bg-gray-700 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-800 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                            <span className="ms-3 text-sm font-medium text-gray-300">Invert Height (Dark is high)</span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div className="bg-secondary p-6 rounded-lg shadow-xl text-center">
                                <h2 className="text-2xl font-semibold mb-4 border-b border-gray-700 pb-2">3. Generate & Download</h2>
                                <div className="flex flex-col items-center justify-center space-y-4">
                                    <button
                                        onClick={handleGenerateStl}
                                        disabled={isLoading}
                                        className="w-full md:w-auto px-8 py-3 bg-primary text-white font-bold rounded-lg hover:bg-accent disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors text-lg"
                                    >
                                        {isLoading ? 'Generating...' : 'Generate STL'}
                                    </button>
                                    
                                    {isLoading && <LoadingSpinner />}
                                    
                                    {stlBlobUrl && !isLoading && (
                                        <a
                                            href={stlBlobUrl}
                                            download={`${imageFile?.name.split('.')[0] || 'model'}.stl`}
                                            className="inline-flex items-center justify-center w-full md:w-auto px-8 py-3 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700 transition-colors text-lg"
                                        >
                                            <DownloadIcon />
                                            Download STL
                                        </a>
                                    )}
                                </div>
                            </div>
                        </>
                    )}
                </main>
            </div>
        </div>
    );
};

export default App;
