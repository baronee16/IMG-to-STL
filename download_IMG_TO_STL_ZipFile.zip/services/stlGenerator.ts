
import type { StlOptions } from '../types';

interface Vector3 {
    x: number;
    y: number;
    z: number;
}

const getPixelZ = (imageData: ImageData, x: number, y: number, options: StlOptions): number => {
    if (x < 0 || x >= imageData.width || y < 0 || y >= imageData.height) {
        return options.baseHeight;
    }

    const pixelIndex = (y * imageData.width + x) * 4;
    const r = imageData.data[pixelIndex];
    const g = imageData.data[pixelIndex + 1];
    const b = imageData.data[pixelIndex + 2];
    
    // Luminance formula for grayscale
    const grayscale = 0.299 * r + 0.587 * g + 0.114 * b;
    const normalizedHeight = grayscale / 255;
    
    const height = options.invert 
        ? (1 - normalizedHeight) * options.maxHeight
        : normalizedHeight * options.maxHeight;

    return options.baseHeight + height;
};

const createFacet = (v1: Vector3, v2: Vector3, v3: Vector3): string => {
    // Calculate normal vector
    const ab = { x: v2.x - v1.x, y: v2.y - v1.y, z: v2.z - v1.z };
    const ac = { x: v3.x - v1.x, y: v3.y - v1.y, z: v3.z - v1.z };

    let normal = {
        x: ab.y * ac.z - ab.z * ac.y,
        y: ab.z * ac.x - ab.x * ac.z,
        z: ab.x * ac.y - ab.y * ac.x
    };

    const length = Math.sqrt(normal.x * normal.x + normal.y * normal.y + normal.z * normal.z);
    if (length > 0) {
        normal.x /= length;
        normal.y /= length;
        normal.z /= length;
    }

    return `facet normal ${normal.x} ${normal.y} ${normal.z}
  outer loop
    vertex ${v1.x} ${v1.y} ${v1.z}
    vertex ${v2.x} ${v2.y} ${v2.z}
    vertex ${v3.x} ${v3.y} ${v3.z}
  endloop
endfacet`;
};

// Use async function to avoid blocking UI on large images
export const generateStl = (imageData: ImageData, options: StlOptions): Promise<Blob> => {
    return new Promise((resolve) => {
        const { width, height } = imageData;
        let stlContent = 'solid image_to_stl\n';
        
        // Scale factor to make model reasonably sized (e.g. 100mm wide)
        const scale = 100 / width;

        for (let y = 0; y < height - 1; y++) {
            for (let x = 0; x < width - 1; x++) {
                // Get Z values for the 4 corners of the pixel square
                const z_tl = getPixelZ(imageData, x, y, options);
                const z_tr = getPixelZ(imageData, x + 1, y, options);
                const z_bl = getPixelZ(imageData, x, y + 1, options);
                const z_br = getPixelZ(imageData, x + 1, y + 1, options);

                // Define the 4 vertices, centered around origin
                const v_tl = { x: (x - width/2) * scale, y: -(y - height/2) * scale, z: z_tl };
                const v_tr = { x: (x + 1 - width/2) * scale, y: -(y - height/2) * scale, z: z_tr };
                const v_bl = { x: (x - width/2) * scale, y: -(y + 1 - height/2) * scale, z: z_bl };
                const v_br = { x: (x + 1 - width/2) * scale, y: -(y + 1 - height/2) * scale, z: z_br };
                
                // Create two triangles for the square
                stlContent += createFacet(v_tl, v_tr, v_bl) + '\n';
                stlContent += createFacet(v_tr, v_br, v_bl) + '\n';
            }
        }
        
        // Add walls
        for(let x = 0; x < width -1; x++) {
            // Top wall
            const z_t1 = getPixelZ(imageData, x, 0, options);
            const z_t2 = getPixelZ(imageData, x + 1, 0, options);
            const v_t1 = {x: (x - width/2) * scale, y: (height/2) * scale, z: z_t1};
            const v_t2 = {x: (x + 1 - width/2) * scale, y: (height/2) * scale, z: z_t2};
            const v_b1 = {x: (x - width/2) * scale, y: (height/2) * scale, z: 0};
            const v_b2 = {x: (x + 1 - width/2) * scale, y: (height/2) * scale, z: 0};
            stlContent += createFacet(v_t1, v_b1, v_t2) + '\n';
            stlContent += createFacet(v_b1, v_b2, v_t2) + '\n';
            // Bottom wall
            const z_b1 = getPixelZ(imageData, x, height-1, options);
            const z_b2 = getPixelZ(imageData, x + 1, height-1, options);
            const v_t1_b = {x: (x - width/2) * scale, y: -(height/2) * scale, z: z_b1};
            const v_t2_b = {x: (x + 1 - width/2) * scale, y: -(height/2) * scale, z: z_b2};
            const v_b1_b = {x: (x - width/2) * scale, y: -(height/2) * scale, z: 0};
            const v_b2_b = {x: (x + 1 - width/2) * scale, y: -(height/2) * scale, z: 0};
            stlContent += createFacet(v_t1_b, v_t2_b, v_b1_b) + '\n';
            stlContent += createFacet(v_b1_b, v_t2_b, v_b2_b) + '\n';

        }
        for(let y = 0; y < height -1; y++) {
            // Left wall
            const z_l1 = getPixelZ(imageData, 0, y, options);
            const z_l2 = getPixelZ(imageData, 0, y+1, options);
            const v_t1 = {x: -width/2*scale, y: -(y-height/2)*scale, z: z_l1};
            const v_t2 = {x: -width/2*scale, y: -(y+1-height/2)*scale, z: z_l2};
            const v_b1 = {x: -width/2*scale, y: -(y-height/2)*scale, z: 0};
            const v_b2 = {x: -width/2*scale, y: -(y+1-height/2)*scale, z: 0};
            stlContent += createFacet(v_t1, v_t2, v_b1) + '\n';
            stlContent += createFacet(v_b1, v_t2, v_b2) + '\n';
            // Right wall
            const z_r1 = getPixelZ(imageData, width-1, y, options);
            const z_r2 = getPixelZ(imageData, width-1, y+1, options);
            const v_t1_r = {x: width/2*scale, y: -(y-height/2)*scale, z: z_r1};
            const v_t2_r = {x: width/2*scale, y: -(y+1-height/2)*scale, z: z_r2};
            const v_b1_r = {x: width/2*scale, y: -(y-height/2)*scale, z: 0};
            const v_b2_r = {x: width/2*scale, y: -(y+1-height/2)*scale, z: 0};
            stlContent += createFacet(v_t1_r, v_b1_r, v_t2_r) + '\n';
            stlContent += createFacet(v_b1_r, v_b2_r, v_t2_r) + '\n';
        }


        // Base
        const v_tl_base = { x: -width/2*scale, y: height/2*scale, z: 0};
        const v_tr_base = { x: width/2*scale, y: height/2*scale, z: 0};
        const v_bl_base = { x: -width/2*scale, y: -height/2*scale, z: 0};
        const v_br_base = { x: width/2*scale, y: -height/2*scale, z: 0};
        stlContent += createFacet(v_tl_base, v_bl_base, v_tr_base) + '\n';
        stlContent += createFacet(v_tr_base, v_bl_base, v_br_base) + '\n';


        stlContent += 'endsolid image_to_stl\n';

        resolve(new Blob([stlContent], { type: 'model/stl' }));
    });
};
