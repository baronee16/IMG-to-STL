
export interface StlOptions {
    baseHeight: number;
    maxHeight: number;
    invert: boolean;
    resolution: number;
}
